var group___ocilib_c_api_subscriptions =
[
    [ "OCI_SubscriptionRegister", "group___ocilib_c_api_subscriptions.html#ga45619c63f00a129c3152a9dbfea75798", null ],
    [ "OCI_SubscriptionUnregister", "group___ocilib_c_api_subscriptions.html#ga0cd32fe33c2e6a2104253df0a7ced19c", null ],
    [ "OCI_SubscriptionAddStatement", "group___ocilib_c_api_subscriptions.html#gab85ad7dc94fe85b69823a18fe690291d", null ],
    [ "OCI_SubscriptionGetName", "group___ocilib_c_api_subscriptions.html#ga260bbf4dc059349b0dad4c6a4f8b6489", null ],
    [ "OCI_SubscriptionGetPort", "group___ocilib_c_api_subscriptions.html#gade4a896a4075ba9f220c00dc8465f4a4", null ],
    [ "OCI_SubscriptionGetTimeout", "group___ocilib_c_api_subscriptions.html#ga17d1434115ea5b3ff1d8657d08f52b0b", null ],
    [ "OCI_SubscriptionGetConnection", "group___ocilib_c_api_subscriptions.html#ga4dec0fc99c5f6ce2652d1616212d365c", null ],
    [ "OCI_EventGetType", "group___ocilib_c_api_subscriptions.html#ga26e6a778b6daa16d4fe8e89c339cbe78", null ],
    [ "OCI_EventGetOperation", "group___ocilib_c_api_subscriptions.html#gaf827cbc855e71e51794ad50c9360eaf6", null ],
    [ "OCI_EventGetDatabase", "group___ocilib_c_api_subscriptions.html#ga3dd621bfdaf9aadb3a2c7a7c476f24b5", null ],
    [ "OCI_EventGetObject", "group___ocilib_c_api_subscriptions.html#gaea831f648aff10278cd70a87aaf6da28", null ],
    [ "OCI_EventGetRowid", "group___ocilib_c_api_subscriptions.html#ga0146520f475bcd0b3fa01606cd0064f4", null ],
    [ "OCI_EventGetSubscription", "group___ocilib_c_api_subscriptions.html#gaec56cab8bd75b11213c1ec7891119f4f", null ]
];