var group___ocilib_c_api_pools =
[
    [ "OCI_PoolCreate", "group___ocilib_c_api_pools.html#gae8dcd0fc7d63c88516b95c478d10d942", null ],
    [ "OCI_PoolFree", "group___ocilib_c_api_pools.html#gad98d2baac08791e3121e577924899d59", null ],
    [ "OCI_PoolGetConnection", "group___ocilib_c_api_pools.html#ga8f8b76255818af6e25f76f298ccf5e70", null ],
    [ "OCI_PoolGetTimeout", "group___ocilib_c_api_pools.html#gae6bdb982e96f0978c0b06d0be96cab65", null ],
    [ "OCI_PoolSetTimeout", "group___ocilib_c_api_pools.html#ga893457c5817ebfc9adf6819ed1d13752", null ],
    [ "OCI_PoolGetNoWait", "group___ocilib_c_api_pools.html#gae4130d1a63f2c8b59314baff1ee76f97", null ],
    [ "OCI_PoolSetNoWait", "group___ocilib_c_api_pools.html#ga6f3b1680200816a4e821a5c87f8f85cc", null ],
    [ "OCI_PoolGetBusyCount", "group___ocilib_c_api_pools.html#ga03f2328d935681970ab2c26d8cf0e7e4", null ],
    [ "OCI_PoolGetOpenedCount", "group___ocilib_c_api_pools.html#ga925e18447dcfc1b5163d147ba619d8a5", null ],
    [ "OCI_PoolGetMin", "group___ocilib_c_api_pools.html#gaf485b3177cee66353857adf798993319", null ],
    [ "OCI_PoolGetMax", "group___ocilib_c_api_pools.html#gacaffd61a334e8736937133f41890341e", null ],
    [ "OCI_PoolGetIncrement", "group___ocilib_c_api_pools.html#ga3b624f2115427ec552d9335b16b827ea", null ],
    [ "OCI_PoolGetStatementCacheSize", "group___ocilib_c_api_pools.html#ga54eeec6e0c48be850a516a5f8ba06bcb", null ],
    [ "OCI_PoolSetStatementCacheSize", "group___ocilib_c_api_pools.html#ga55ff91d6f22208501911071c491f20fe", null ]
];