var group___ocilib_c_api_transactions =
[
    [ "OCI_Commit", "group___ocilib_c_api_transactions.html#gadc75ccc3334477a3b4ceeb609f7ed544", null ],
    [ "OCI_Rollback", "group___ocilib_c_api_transactions.html#gafe6bf0b2d454a3e2f78a1da8063661fc", null ],
    [ "OCI_SetAutoCommit", "group___ocilib_c_api_transactions.html#ga43be7c3750fab514da607cc0425fde1f", null ],
    [ "OCI_GetAutoCommit", "group___ocilib_c_api_transactions.html#gaa625d9f9d4741c6a6a7c5e0bf0db0997", null ],
    [ "OCI_TransactionCreate", "group___ocilib_c_api_transactions.html#ga2360c7635c536f313b93c6437aa9e1e8", null ],
    [ "OCI_TransactionFree", "group___ocilib_c_api_transactions.html#ga39a61a42c913f19731b830fb4efaf574", null ],
    [ "OCI_TransactionStart", "group___ocilib_c_api_transactions.html#ga7a4954200fde27bf2e1c2d0b90018062", null ],
    [ "OCI_TransactionStop", "group___ocilib_c_api_transactions.html#ga1c5d44275fa024ae1079d1b9a07f3d1b", null ],
    [ "OCI_TransactionResume", "group___ocilib_c_api_transactions.html#gabb18246fb0c96c4148d339bfb0a596e3", null ],
    [ "OCI_TransactionPrepare", "group___ocilib_c_api_transactions.html#ga161ac7b488a99a3c3f9748f50cced291", null ],
    [ "OCI_TransactionForget", "group___ocilib_c_api_transactions.html#ga5ea692078a6645d9efc9e242ae50e017", null ],
    [ "OCI_TransactionGetMode", "group___ocilib_c_api_transactions.html#gac13bc63411edaa36a098c2a4a1406f12", null ],
    [ "OCI_TransactionGetTimeout", "group___ocilib_c_api_transactions.html#gaab95873de72150f5c4604211be7286b1", null ]
];