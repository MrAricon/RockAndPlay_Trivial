var classocilib_1_1_subscription =
[
    [ "NotifyHandlerProc", "classocilib_1_1_subscription.html#aa557f2ff8b04b1c465f4fb2c901fe8e7", null ],
    [ "ChangeTypes", "classocilib_1_1_subscription.html#a929919f394eaba498043864a2b6e2aec", null ],
    [ "ChangeTypesValues", "classocilib_1_1_subscription.html#aa2667ca0384af70f0c17d6bdc28ed082", [
      [ "ObjectChanges", "classocilib_1_1_subscription.html#aa2667ca0384af70f0c17d6bdc28ed082aecdfb6fffabfbdf15eae6d80ad04a0d2", null ],
      [ "RowChanges", "classocilib_1_1_subscription.html#aa2667ca0384af70f0c17d6bdc28ed082a0c4a4ff11ff9e8dd7a06167e42c73ef8", null ],
      [ "DatabaseChanges", "classocilib_1_1_subscription.html#aa2667ca0384af70f0c17d6bdc28ed082a7e4d7d4f031f8fc53b539b6c63ef8a2d", null ],
      [ "AllChanges", "classocilib_1_1_subscription.html#aa2667ca0384af70f0c17d6bdc28ed082a5a55eb308dfae1200c7d22df8957aa3a", null ]
    ] ],
    [ "Subscription", "classocilib_1_1_subscription.html#a40b835ebe39948c113f32a51720e82ea", null ],
    [ "Register", "classocilib_1_1_subscription.html#a44f8bca8a9479fe38dde565890850389", null ],
    [ "Unregister", "classocilib_1_1_subscription.html#a1f6e12327beee0faef2d15e0244d090a", null ],
    [ "Watch", "classocilib_1_1_subscription.html#a0bbced3f0c3111880bff1d9f8b607a38", null ],
    [ "GetName", "classocilib_1_1_subscription.html#a92517e6ef6bf355fbe99f77a4302a455", null ],
    [ "GetTimeout", "classocilib_1_1_subscription.html#a5ebcdbd6229c7222c89be43a8c562044", null ],
    [ "GetPort", "classocilib_1_1_subscription.html#ac928d03b25df753c3ea61b6d74f58234", null ],
    [ "GetConnection", "classocilib_1_1_subscription.html#a4e6aaf207d301b2ec51f63ddfd60f5a5", null ]
];