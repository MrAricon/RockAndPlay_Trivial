var modules =
[
    [ "Installation", "group___ocilib_c_api_installation.html", null ],
    [ "DataTypes", "group___ocilib_c_api_data_types.html", null ],
    [ "C API", "group___ocilib_c_api.html", "group___ocilib_c_api" ],
    [ "C++ API", "group___ocilib_cpp_api.html", "group___ocilib_cpp_api" ]
];