var group___ocilib_c_api_instances_management =
[
    [ "OCI_DatabaseStartup", "group___ocilib_c_api_instances_management.html#ga5e05ed174b5127b0f1d4eac851d03ab7", null ],
    [ "OCI_DatabaseShutdown", "group___ocilib_c_api_instances_management.html#ga107e2e1fefd33945702db1b83e34c8cc", null ]
];