var classocilib_1_1_reference =
[
    [ "Reference", "classocilib_1_1_reference.html#a3c0cce21bf25ec57220bea9c79d5a0df", null ],
    [ "Reference", "classocilib_1_1_reference.html#ae05f73e86ee9f6203bb32f1d618eddaf", null ],
    [ "GetTypeInfo", "classocilib_1_1_reference.html#a6137e562e923832a525fe2fc00fa564c", null ],
    [ "GetObject", "classocilib_1_1_reference.html#afeee7701caaa5a1a383d62f0f98def4e", null ],
    [ "IsReferenceNull", "classocilib_1_1_reference.html#adf41069c96d59b38fb731f18c0604cef", null ],
    [ "SetReferenceNull", "classocilib_1_1_reference.html#aa9ffdde7e84ff990ff3bd903570fdd85", null ],
    [ "Clone", "classocilib_1_1_reference.html#a2d0838e9cd826b1c545d6db2b1265bea", null ],
    [ "ToString", "classocilib_1_1_reference.html#a614dbca2e61021aa0c2a2cf91a3d2034", null ]
];