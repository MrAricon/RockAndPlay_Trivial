var group___ocilib_c_api_metadata =
[
    [ "OCI_TypeInfoGet", "group___ocilib_c_api_metadata.html#ga170733509803e73193ed3d7d858e68f8", null ],
    [ "OCI_TypeInfoGetType", "group___ocilib_c_api_metadata.html#gad9d81f650ac18068043213de8baccdef", null ],
    [ "OCI_TypeInfoGetConnection", "group___ocilib_c_api_metadata.html#ga394592a9ee3685258c37d9a90e94d8e2", null ],
    [ "OCI_TypeInfoFree", "group___ocilib_c_api_metadata.html#ga328dc2829ae4fc10065b7299c0645b24", null ],
    [ "OCI_TypeInfoGetColumnCount", "group___ocilib_c_api_metadata.html#gad35f0d4af92fbbaca42170f3882367b2", null ],
    [ "OCI_TypeInfoGetColumn", "group___ocilib_c_api_metadata.html#ga20ef9e54167c854d002970b2f1720af5", null ],
    [ "OCI_TypeInfoGetName", "group___ocilib_c_api_metadata.html#gabad373e8e284b561284b76597bd9455b", null ],
    [ "OCI_TypeInfoIsFinalType", "group___ocilib_c_api_metadata.html#gabb9ceb4dfbfa55fe856fcb00a7d31b13", null ],
    [ "OCI_TypeInfoGetSuperType", "group___ocilib_c_api_metadata.html#ga627ac5c6bbb36e845156dd046218d887", null ]
];