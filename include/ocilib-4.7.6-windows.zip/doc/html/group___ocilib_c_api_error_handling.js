var group___ocilib_c_api_error_handling =
[
    [ "OCI_SetErrorHandler", "group___ocilib_c_api_error_handling.html#ga748ca2a086c8adeb08e104e64155767e", null ],
    [ "OCI_GetLastError", "group___ocilib_c_api_error_handling.html#ga7a49ce8b93a89f104658b293d435a0e2", null ],
    [ "OCI_ErrorGetString", "group___ocilib_c_api_error_handling.html#ga6df58afd698cd1e16d6a7f38afce8027", null ],
    [ "OCI_ErrorGetType", "group___ocilib_c_api_error_handling.html#ga5e55028f0874d30cf80d2ffed349d0af", null ],
    [ "OCI_ErrorGetOCICode", "group___ocilib_c_api_error_handling.html#gac68b56831d0ca0a45fb8da25f97d4e07", null ],
    [ "OCI_ErrorGetInternalCode", "group___ocilib_c_api_error_handling.html#ga148d833e4faf47b78cebb4cb4aebcc1e", null ],
    [ "OCI_ErrorGetConnection", "group___ocilib_c_api_error_handling.html#ga3237c442184faa28a5bfb12bd635eb20", null ],
    [ "OCI_ErrorGetStatement", "group___ocilib_c_api_error_handling.html#ga33aceb5bd97aba516ed1494d7715fb37", null ],
    [ "OCI_ErrorGetRow", "group___ocilib_c_api_error_handling.html#ga6f2a9404899d7365fbc51ded9bff5c8b", null ],
    [ "OCI_ErrorGetLocation", "group___ocilib_c_api_error_handling.html#gaf27b583d2d6a9c45c77fad1921a26f2e", null ]
];