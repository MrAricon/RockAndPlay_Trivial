var group___ocilib_c_api_pl_sql =
[
    [ "OCI_ServerEnableOutput", "group___ocilib_c_api_pl_sql.html#ga913c2e4be688b7e68222928a51bd8f7f", null ],
    [ "OCI_ServerDisableOutput", "group___ocilib_c_api_pl_sql.html#ga4a0366bba206b74dcbca8464198e41ec", null ],
    [ "OCI_ServerGetOutput", "group___ocilib_c_api_pl_sql.html#ga03a7fc35a0a39865d6b376c0f43ecf5a", null ]
];