var searchData=
[
  ['date_0',['Date',['../classocilib_1_1_date.html#aeb0f3012f217aaaa9fc5686288f091e2',1,'ocilib::Date::Date(bool create=false)'],['../classocilib_1_1_date.html#a3e1c5c1a999a51ddc267fd3f0b77c975',1,'ocilib::Date::Date(const otext *str, const otext *format=OTEXT(&quot;&quot;))'],['../classocilib_1_1_date.html#ad493a3b361497700feaa1af17d02a3e8',1,'ocilib::Date::Date(const ostring &amp;str, const ostring &amp;format=OTEXT(&quot;&quot;))']]],
  ['daysbetween_1',['DaysBetween',['../classocilib_1_1_date.html#aed8bcb119b2692931be3affa0bd3ce9d',1,'ocilib::Date']]],
  ['delete_2',['Delete',['../classocilib_1_1_collection.html#aec5b2e080fc4e2dd0e3985970112a3a6',1,'ocilib::Collection']]],
  ['dequeue_3',['Dequeue',['../classocilib_1_1_dequeue.html#a847e053d022db97fb403caf0cc6e3bc6',1,'ocilib::Dequeue']]],
  ['describe_4',['Describe',['../classocilib_1_1_statement.html#ac967f297cfd4ca08f431c647c2fdc793',1,'ocilib::Statement']]],
  ['destroy_5',['Destroy',['../classocilib_1_1_thread.html#af672a19847e798b83fe3f5d7dd0ba16c',1,'ocilib::Thread::Destroy()'],['../classocilib_1_1_mutex.html#a4bf7c7f3eba27a0ad21777fab817b00f',1,'ocilib::Mutex::Destroy()']]],
  ['directpath_6',['DirectPath',['../classocilib_1_1_direct_path.html#adf36e39ec5d2368398229cd1d67dc29f',1,'ocilib::DirectPath']]],
  ['disableserveroutput_7',['DisableServerOutput',['../classocilib_1_1_connection.html#a5dbac14acd330f73defd8bc9c8ea6a63',1,'ocilib::Connection']]],
  ['drop_8',['Drop',['../classocilib_1_1_queue.html#adc6da276e2992b09f4376ffa57a7f36b',1,'ocilib::Queue::Drop()'],['../classocilib_1_1_queue_table.html#a0c9551b7ad995fb2d7ee1d509813a8cb',1,'ocilib::QueueTable::Drop()']]]
];
