var searchData=
[
  ['persistent_0',['Persistent',['../classocilib_1_1_object.html#afe1b53292d48efb6e04ac9df592503a9a5d8fc8cbe9d0aeee69c4da2ef8afe787',1,'ocilib::Object::Persistent()'],['../classocilib_1_1_queue_table.html#a455fed96f1e9bfe899b0143b45a03553a0c8618aef189f1c6c962c2300eeed0ac',1,'ocilib::QueueTable::Persistent()']]],
  ['processed_1',['Processed',['../classocilib_1_1_message.html#a2aa8565d58cf9c813deabaa0cadff6bca0d41191cc47f046e3fa59c64d429125d',1,'ocilib::Message']]]
];
