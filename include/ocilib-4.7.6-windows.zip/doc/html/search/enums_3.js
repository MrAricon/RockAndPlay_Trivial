var searchData=
[
  ['datatypevalues_0',['DataTypeValues',['../namespaceocilib.html#ac3f00ba4e438728cf3377542245d21e6',1,'ocilib']]],
  ['dequeuemodevalues_1',['DequeueModeValues',['../classocilib_1_1_dequeue.html#a905f0addefd1d1092009985009cbceb8',1,'ocilib::Dequeue']]],
  ['dequeuevisibilityvalues_2',['DequeueVisibilityValues',['../classocilib_1_1_dequeue.html#a082c13c482ccc925dd8efc6121c44af2',1,'ocilib::Dequeue']]]
];
