var searchData=
[
  ['lob_0',['Lob',['../classocilib_1_1_lob.html',1,'ocilib']]],
  ['long_1',['Long',['../classocilib_1_1_long.html',1,'ocilib']]]
];
