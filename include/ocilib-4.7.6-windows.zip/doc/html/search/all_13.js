var searchData=
[
  ['unregister_0',['Unregister',['../classocilib_1_1_event.html#a870a4e6122a5258f3a2291414581383ead90ec9724417d56869f76366a04bdcae',1,'ocilib::Event::Unregister()'],['../classocilib_1_1_subscription.html#a1f6e12327beee0faef2d15e0244d090a',1,'ocilib::Subscription::Unregister()']]],
  ['unsubscribe_1',['Unsubscribe',['../classocilib_1_1_dequeue.html#a32d54ca7cda80bc50c090a2ca9f1f5ba',1,'ocilib::Dequeue']]],
  ['updatetimezone_2',['UpdateTimeZone',['../classocilib_1_1_interval.html#ac678c97f4b51f284e5fcccc924f427c5',1,'ocilib::Interval']]],
  ['using_20oci_20handles_20directly_3',['Using OCI Handles directly',['../group___ocilib_c_api_raw_handles.html',1,'']]]
];
