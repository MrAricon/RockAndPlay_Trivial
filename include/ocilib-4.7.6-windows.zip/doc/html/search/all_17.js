var searchData=
[
  ['_7eexception_0',['~Exception',['../classocilib_1_1_exception.html#aa190fa19d909203574f06513b638acd7',1,'ocilib::Exception']]]
];
