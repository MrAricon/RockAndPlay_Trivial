var searchData=
[
  ['lobtypevalues_0',['LobTypeValues',['../namespaceocilib.html#ac6e39e0361fffd586dcb5dd293b6e2c6',1,'ocilib']]],
  ['longmodevalues_1',['LongModeValues',['../classocilib_1_1_statement.html#a095c882ba807ccba7bf693b5652385e1',1,'ocilib::Statement']]],
  ['longtypevalues_2',['LongTypeValues',['../namespaceocilib.html#a221f8e33d7feb78a888d65939e19c36c',1,'ocilib']]]
];
