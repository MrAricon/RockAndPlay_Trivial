var searchData=
[
  ['initialize_0',['Initialize',['../classocilib_1_1_environment.html#a83613d62908717ddf7d0ac797d63120a',1,'ocilib::Environment']]],
  ['initialized_1',['Initialized',['../classocilib_1_1_environment.html#aaa7d3f2ac54426c7f585a3e9c28a6119',1,'ocilib::Environment']]],
  ['interval_2',['Interval',['../classocilib_1_1_interval.html#adf93d464a7804eaacba0cd8a6e83efe1',1,'ocilib::Interval::Interval()'],['../classocilib_1_1_interval.html#a58549d5f7914cbcab99db43e9fd493fc',1,'ocilib::Interval::Interval(IntervalType type)'],['../classocilib_1_1_interval.html#a2fce8e46fd534247603bd606ac6f0994',1,'ocilib::Interval::Interval(IntervalType type, const ostring &amp;data)']]],
  ['isattributenull_3',['IsAttributeNull',['../classocilib_1_1_object.html#aa48d3265a6bad6aff06e9e6ef20e3647',1,'ocilib::Object']]],
  ['ischarsemanticused_4',['IsCharSemanticUsed',['../classocilib_1_1_column.html#a63cad955f634eb2532a61c8404a2bb9c',1,'ocilib::Column']]],
  ['iscolumnnull_5',['IsColumnNull',['../classocilib_1_1_resultset.html#ab164ed08e441c46a7bbf1fdb010878e7',1,'ocilib::Resultset::IsColumnNull(unsigned int index) const'],['../classocilib_1_1_resultset.html#a10ec4abace9d08ea72cb4d44887e58a3',1,'ocilib::Resultset::IsColumnNull(const ostring &amp;name) const']]],
  ['isdatanull_6',['IsDataNull',['../classocilib_1_1_bind_info.html#aba0270cfa044675ff9669b23415012a8',1,'ocilib::BindInfo']]],
  ['iselementnull_7',['IsElementNull',['../classocilib_1_1_collection.html#a9a4646a62b8104ae35439c1a71a28a5b',1,'ocilib::Collection']]],
  ['isfinaltype_8',['IsFinalType',['../classocilib_1_1_type_info.html#a6fcc98463e8e0b2e25a52b89f11b048b',1,'ocilib::TypeInfo']]],
  ['isnullable_9',['IsNullable',['../classocilib_1_1_column.html#a4dc2ccbdd94b0bbc9952459fa06d4102',1,'ocilib::Column']]],
  ['isopened_10',['IsOpened',['../classocilib_1_1_file.html#ad4eaa65aecca385912cfefce402db2bd',1,'ocilib::File']]],
  ['isrebindingallowed_11',['IsRebindingAllowed',['../classocilib_1_1_statement.html#af5265f8b6f1d5cc2e2f919b6a65804db',1,'ocilib::Statement']]],
  ['isreferencenull_12',['IsReferenceNull',['../classocilib_1_1_reference.html#adf41069c96d59b38fb731f18c0604cef',1,'ocilib::Reference']]],
  ['isremote_13',['IsRemote',['../classocilib_1_1_lob.html#a6ae3b89d68c6c031dec69c0f081f9fb1',1,'ocilib::Lob']]],
  ['isserveralive_14',['IsServerAlive',['../classocilib_1_1_connection.html#a04ea902cc34aaf7888955a30eba5326a',1,'ocilib::Connection']]],
  ['istafcapable_15',['IsTAFCapable',['../classocilib_1_1_connection.html#a823b6cc30418baae943fd29d2280418b',1,'ocilib::Connection']]],
  ['istemporary_16',['IsTemporary',['../classocilib_1_1_lob.html#a2e2fb48070924721883e9f0efc9fd2c0',1,'ocilib::Lob']]],
  ['isvalid_17',['IsValid',['../classocilib_1_1_date.html#ae767e2f48b8232cb2771fb52de581026',1,'ocilib::Date::IsValid()'],['../classocilib_1_1_interval.html#afc3b5caff12b6ff869d66e66f136b227',1,'ocilib::Interval::IsValid()'],['../classocilib_1_1_timestamp.html#aade14ecded574b75496bf606034309a3',1,'ocilib::Timestamp::IsValid()']]]
];
