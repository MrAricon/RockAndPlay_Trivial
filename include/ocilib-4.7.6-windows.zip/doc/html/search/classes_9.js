var searchData=
[
  ['managedbuffer_0',['ManagedBuffer',['../classocilib_1_1core_1_1_managed_buffer.html',1,'ocilib::core']]],
  ['message_1',['Message',['../classocilib_1_1_message.html',1,'ocilib']]],
  ['mutex_2',['Mutex',['../classocilib_1_1_mutex.html',1,'ocilib']]]
];
