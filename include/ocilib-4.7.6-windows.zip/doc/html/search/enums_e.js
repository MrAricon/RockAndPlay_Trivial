var searchData=
[
  ['queuetypevalues_0',['QueueTypeValues',['../classocilib_1_1_queue.html#a3b76471a9d4ade9395fd9d96a822e217',1,'ocilib::Queue']]]
];
