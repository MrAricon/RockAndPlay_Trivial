var group___ocilib_c_api_longs =
[
    [ "OCI_LongCreate", "group___ocilib_c_api_longs.html#gaef6b124865144b2602f0ea234d18622d", null ],
    [ "OCI_LongFree", "group___ocilib_c_api_longs.html#ga645e23ae25f61403cda590b84d7c515a", null ],
    [ "OCI_LongGetType", "group___ocilib_c_api_longs.html#gab3d356c66a338e89f2442f41e2916eeb", null ],
    [ "OCI_LongRead", "group___ocilib_c_api_longs.html#ga8bacb9883122e2925613927695fe54dd", null ],
    [ "OCI_LongWrite", "group___ocilib_c_api_longs.html#gac5c5c7779dc465f3f5e06e8a72358452", null ],
    [ "OCI_LongGetSize", "group___ocilib_c_api_longs.html#ga7843603fb41ecb402feeb8e19516d19f", null ],
    [ "OCI_LongGetBuffer", "group___ocilib_c_api_longs.html#ga2d1b3cecae8b8867a29fe4c6f641341b", null ]
];