var group___ocilib_c_api_files =
[
    [ "OCI_FileCreate", "group___ocilib_c_api_files.html#ga28b7af3b3d80ee55218089e96791b120", null ],
    [ "OCI_FileFree", "group___ocilib_c_api_files.html#gaa618f629670685cbb02044856d36dd38", null ],
    [ "OCI_FileArrayCreate", "group___ocilib_c_api_files.html#ga6e68cb422de0d7464323bfbb9cb33124", null ],
    [ "OCI_FileArrayFree", "group___ocilib_c_api_files.html#gab59a84709566624a6803de312b4450d4", null ],
    [ "OCI_FileGetType", "group___ocilib_c_api_files.html#ga0ef4a19de27ebe0db2421b71f7b93620", null ],
    [ "OCI_FileSeek", "group___ocilib_c_api_files.html#ga3dbddfb33e47382476aa71bde147c7b6", null ],
    [ "OCI_FileGetOffset", "group___ocilib_c_api_files.html#gaa00126400e81319e542f6097d9830e59", null ],
    [ "OCI_FileRead", "group___ocilib_c_api_files.html#ga616bfe9db949af310efe532091c0b3e5", null ],
    [ "OCI_FileGetSize", "group___ocilib_c_api_files.html#gaf1849513ad3b19ddb6ed30973e2a8eb6", null ],
    [ "OCI_FileExists", "group___ocilib_c_api_files.html#ga50ca363026bbe7e251826949194d2245", null ],
    [ "OCI_FileSetName", "group___ocilib_c_api_files.html#ga8ed41c02a9089b49fd8093313200cf28", null ],
    [ "OCI_FileGetDirectory", "group___ocilib_c_api_files.html#ga83b4b4d4cfdbaf363d30f002e1ab7827", null ],
    [ "OCI_FileGetName", "group___ocilib_c_api_files.html#ga175384966477aca0ffd2a352efb3b8b1", null ],
    [ "OCI_FileOpen", "group___ocilib_c_api_files.html#gaa033419fe40d095fee0df7175112e559", null ],
    [ "OCI_FileIsOpen", "group___ocilib_c_api_files.html#ga0c95c0baf32e554869141600de0cf33b", null ],
    [ "OCI_FileClose", "group___ocilib_c_api_files.html#gadaba85bc80450119f8b7b4d9d0832872", null ],
    [ "OCI_FileIsEqual", "group___ocilib_c_api_files.html#ga2ce317e2b1a0fa72392af0a29f42be86", null ],
    [ "OCI_FileAssign", "group___ocilib_c_api_files.html#ga068eee96a39fd164c9c2ac8bf9c9c13d", null ],
    [ "OCI_FileGetConnection", "group___ocilib_c_api_files.html#ga2de329ddaea5fd20988f191883ec5586", null ]
];