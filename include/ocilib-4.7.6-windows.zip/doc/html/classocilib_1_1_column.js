var classocilib_1_1_column =
[
    [ "PropertyFlags", "classocilib_1_1_column.html#ab243703a689021b8a13391cd3e31e896", null ],
    [ "PropertyFlagsValues", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3", [
      [ "NoFlags", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3affcfb9a37acec1b89be83c4368a3fc5c", null ],
      [ "IsIdentity", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3ace16a6cc7e7015721b56eb6a16820235", null ],
      [ "IsGeneratedAlways", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3a0b6cacb8ddb56da9cd8bb2d0589a16db", null ],
      [ "IsGeneratedByDefaultOnNull", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3afd40f7f0eb1cee692fdb0cb9f4260b15", null ],
      [ "IsLogicalPartitioning", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3abc86d2c287fb9f194be09e4dffba0d87", null ],
      [ "IsGeneratedByContainers", "classocilib_1_1_column.html#a297ea71454f03a3c3ab3e071ec4fd1c3a16019d6dff37c2b44fe4b8ab603a000d", null ]
    ] ],
    [ "GetName", "classocilib_1_1_column.html#a923091dd7e86eb436320db73e4f4f8e8", null ],
    [ "GetSQLType", "classocilib_1_1_column.html#a0b795409c60244f3893dbfacb398fc53", null ],
    [ "GetFullSQLType", "classocilib_1_1_column.html#aab30488251d61f147d63b24d4a53965e", null ],
    [ "GetType", "classocilib_1_1_column.html#aeac6a67879dfa19b4ba7f95e27866ec1", null ],
    [ "GetSubType", "classocilib_1_1_column.html#ad3cd153f4138ebee0c394a4602c23615", null ],
    [ "GetCharsetForm", "classocilib_1_1_column.html#ae4a3b3bf99e42edf7921c3dc7958b0d5", null ],
    [ "GetCollationID", "classocilib_1_1_column.html#a24769d1d2b86d76d29e7e9fdca47aaeb", null ],
    [ "GetSize", "classocilib_1_1_column.html#a902bbe7347057cdcb5bd82abcb18cdff", null ],
    [ "GetScale", "classocilib_1_1_column.html#a7610858790b3806258da4d3d7b6ba63d", null ],
    [ "GetPrecision", "classocilib_1_1_column.html#a3330317fcf56034809d1a389e1ba849c", null ],
    [ "GetFractionalPrecision", "classocilib_1_1_column.html#acc4f3f0440b1384e4f61b18626309060", null ],
    [ "GetLeadingPrecision", "classocilib_1_1_column.html#af287d5ac4c014d572e8200a3b1bdae39", null ],
    [ "GetPropertyFlags", "classocilib_1_1_column.html#a7c87171e14265c1419a5c469c5e8796a", null ],
    [ "IsNullable", "classocilib_1_1_column.html#a4dc2ccbdd94b0bbc9952459fa06d4102", null ],
    [ "IsCharSemanticUsed", "classocilib_1_1_column.html#a63cad955f634eb2532a61c8404a2bb9c", null ],
    [ "GetTypeInfo", "classocilib_1_1_column.html#a4782425a073f14ec695361fae1242643", null ]
];