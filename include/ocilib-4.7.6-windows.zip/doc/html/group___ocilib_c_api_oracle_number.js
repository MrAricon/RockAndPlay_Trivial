var group___ocilib_c_api_oracle_number =
[
    [ "OCI_NumberCreate", "group___ocilib_c_api_oracle_number.html#gaf7355a4ed42f04e3b3f96ca3feceecff", null ],
    [ "OCI_NumberFree", "group___ocilib_c_api_oracle_number.html#ga8d0378575508a6f57141988686ac76eb", null ],
    [ "OCI_NumberArrayCreate", "group___ocilib_c_api_oracle_number.html#ga7782149e8a1ffef32300b0ad9f912367", null ],
    [ "OCI_NumberArrayFree", "group___ocilib_c_api_oracle_number.html#ga1ffb5857696512ec556406434a4e2803", null ],
    [ "OCI_NumberAssign", "group___ocilib_c_api_oracle_number.html#gaed7cf75ee3af6cac734f1963f486d5e9", null ],
    [ "OCI_NumberToText", "group___ocilib_c_api_oracle_number.html#gac8cb94d41a6ca3e77e586523d5e3126e", null ],
    [ "OCI_NumberFromText", "group___ocilib_c_api_oracle_number.html#gaa34870402fb69d90842840010920050f", null ],
    [ "OCI_NumberGetContent", "group___ocilib_c_api_oracle_number.html#ga0ce6b726b59eb09b4a5801fc781265af", null ],
    [ "OCI_NumberSetContent", "group___ocilib_c_api_oracle_number.html#ga73243d97ac054a7fc1463dbc75a7ec86", null ],
    [ "OCI_NumberSetValue", "group___ocilib_c_api_oracle_number.html#ga063ff2f32c8777d124f6fb02e57f51bf", null ],
    [ "OCI_NumberGetValue", "group___ocilib_c_api_oracle_number.html#gae50a55dc028b3c28db82bcb8701086ef", null ],
    [ "OCI_NumberAdd", "group___ocilib_c_api_oracle_number.html#gab50d04111a9ba8649758a41cf532e847", null ],
    [ "OCI_NumberSub", "group___ocilib_c_api_oracle_number.html#ga06548838ee310ee51ea87ab04fffb42d", null ],
    [ "OCI_NumberMultiply", "group___ocilib_c_api_oracle_number.html#ga2b2d62cd254e2398e1f974b9be1421fb", null ],
    [ "OCI_NumberDivide", "group___ocilib_c_api_oracle_number.html#gaa1dea6ef965992cd7e9d4a12c2613098", null ],
    [ "OCI_NumberCompare", "group___ocilib_c_api_oracle_number.html#ga1a49652dde79614d14f739ba3ec7a78f", null ]
];