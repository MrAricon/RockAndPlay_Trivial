var group___ocilib_c_api_statements =
[
    [ "OCI_StatementCreate", "group___ocilib_c_api_statements.html#ga155a95c89d2e8e162acb61383a56f77d", null ],
    [ "OCI_StatementFree", "group___ocilib_c_api_statements.html#ga8faf400001d7132469396b67ae8894d0", null ],
    [ "OCI_Prepare", "group___ocilib_c_api_statements.html#gaaedce0c8f66eb60445fb759900d32f04", null ],
    [ "OCI_Execute", "group___ocilib_c_api_statements.html#gac4fae0835b45409e141eb1b4518fa89c", null ],
    [ "OCI_ExecuteStmt", "group___ocilib_c_api_statements.html#ga533ada0a945118e7e62e2357d956dcf2", null ],
    [ "OCI_Parse", "group___ocilib_c_api_statements.html#ga248aacd7e8e87d26082054dfe68a2367", null ],
    [ "OCI_Describe", "group___ocilib_c_api_statements.html#ga499f2ecbc9ac9de1bccedc5af1cef1ca", null ],
    [ "OCI_GetSql", "group___ocilib_c_api_statements.html#gae0b460b30f9b0bac72eccc267ffd96d2", null ],
    [ "OCI_GetSqlIdentifier", "group___ocilib_c_api_statements.html#ga7f3c6bc49a455074d7ad39dbdd65ad60", null ],
    [ "OCI_GetSqlErrorPos", "group___ocilib_c_api_statements.html#gab3ec87b4fb46ab1752341561912449a9", null ],
    [ "OCI_GetAffectedRows", "group___ocilib_c_api_statements.html#ga0af3308fa16a0a0e591b67c7ab7211a7", null ],
    [ "OCI_GetSQLCommand", "group___ocilib_c_api_statements.html#ga8d320ae22ef2449a1548c962a03efcca", null ],
    [ "OCI_GetSQLVerb", "group___ocilib_c_api_statements.html#gafa3fc1352d793580b76723b7dea622a7", null ]
];