var group___ocilib_c_api_statement_control =
[
    [ "OCI_GetStatementType", "group___ocilib_c_api_statement_control.html#gadeb0d05ffe0672a5325440ad2c49b802", null ],
    [ "OCI_SetFetchMode", "group___ocilib_c_api_statement_control.html#ga1993321bb525eef88957b5a37a54219b", null ],
    [ "OCI_GetFetchMode", "group___ocilib_c_api_statement_control.html#ga81d5e181fdd7c8db9aa2e77564a6dc81", null ],
    [ "OCI_SetBindMode", "group___ocilib_c_api_statement_control.html#ga927b734436e44accd929209fbcd94667", null ],
    [ "OCI_GetBindMode", "group___ocilib_c_api_statement_control.html#ga55231c6c248d1dc379e125879c8e1844", null ],
    [ "OCI_SetBindAllocation", "group___ocilib_c_api_statement_control.html#ga4f4811d4d8174cfaf9ef99be6f4c37d6", null ],
    [ "OCI_GetBindAllocation", "group___ocilib_c_api_statement_control.html#ga1ef7ea16ff150d8515be1010cb69503e", null ],
    [ "OCI_SetFetchSize", "group___ocilib_c_api_statement_control.html#gad1ad2c5edc80a11816a39485a44518e7", null ],
    [ "OCI_GetFetchSize", "group___ocilib_c_api_statement_control.html#gacc0f805055a7ae7febd936785f76bbf6", null ],
    [ "OCI_SetPrefetchSize", "group___ocilib_c_api_statement_control.html#gacd51004bf5e62b397d4702a272947c79", null ],
    [ "OCI_GetPrefetchSize", "group___ocilib_c_api_statement_control.html#ga01753b667b1d879dd2c32a2f65331eb9", null ],
    [ "OCI_SetPrefetchMemory", "group___ocilib_c_api_statement_control.html#ga0a3716423dccf24d394b6435cd2dbcae", null ],
    [ "OCI_GetPrefetchMemory", "group___ocilib_c_api_statement_control.html#ga28f0d61d1a194fcaa5d9b035c4975a3e", null ],
    [ "OCI_SetLongMaxSize", "group___ocilib_c_api_statement_control.html#ga5eaac9bdb276fe0753fbf507615184f9", null ],
    [ "OCI_GetLongMaxSize", "group___ocilib_c_api_statement_control.html#ga4205adb98cd8eaedaeeb6297c1297992", null ],
    [ "OCI_SetLongMode", "group___ocilib_c_api_statement_control.html#gab48b8c050e05fbf488794005bca68d4a", null ],
    [ "OCI_GetLongMode", "group___ocilib_c_api_statement_control.html#gab8293f13f00235613b295bb3ce16b066", null ],
    [ "OCI_StatementGetConnection", "group___ocilib_c_api_statement_control.html#gaf904543ff555ba1de6418770efda32e5", null ]
];