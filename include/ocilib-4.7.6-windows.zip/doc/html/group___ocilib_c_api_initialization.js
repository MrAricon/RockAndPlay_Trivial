var group___ocilib_c_api_initialization =
[
    [ "OCI_Initialize", "group___ocilib_c_api_initialization.html#gad46f4bcaec7ad58d4e82b51bf065a401", null ],
    [ "OCI_Cleanup", "group___ocilib_c_api_initialization.html#ga0395802e1f357326fe0e968c344f437c", null ],
    [ "OCI_GetOCICompileVersion", "group___ocilib_c_api_initialization.html#ga471fe81fceb42d90eb82fc3b2e1e4351", null ],
    [ "OCI_GetOCIRuntimeVersion", "group___ocilib_c_api_initialization.html#gaa00063a7def6b00894520386c7a7696a", null ],
    [ "OCI_GetImportMode", "group___ocilib_c_api_initialization.html#gab8ca72a656755584d4b5272e5a3598c6", null ],
    [ "OCI_GetCharset", "group___ocilib_c_api_initialization.html#ga65fd83e537219b617da5d1e0c198843a", null ],
    [ "OCI_GetAllocatedBytes", "group___ocilib_c_api_initialization.html#gaf483cdc4b9a4826a950b63cafed46ef7", null ],
    [ "OCI_EnableWarnings", "group___ocilib_c_api_initialization.html#ga98eb3445d035b77d2c666fc09ba9b5fa", null ],
    [ "OCI_SetHAHandler", "group___ocilib_c_api_initialization.html#ga5a3480a53073170bb1f7568b5b23cd8e", null ]
];