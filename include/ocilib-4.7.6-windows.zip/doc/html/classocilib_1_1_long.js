var classocilib_1_1_long =
[
    [ "Long", "classocilib_1_1_long.html#a039a79be8c50426fc8e9060246bb28a5", null ],
    [ "Long", "classocilib_1_1_long.html#a4541c7bff32db90366434199adcc8507", null ],
    [ "Write", "classocilib_1_1_long.html#a36eacb25606221605a427cb26d147a91", null ],
    [ "GetLength", "classocilib_1_1_long.html#a92d62dfe3fa9d9fcc7b5d66cdc32f06b", null ],
    [ "GetContent", "classocilib_1_1_long.html#a9d4dde4afc13a947dd22715e1a268d0d", null ]
];