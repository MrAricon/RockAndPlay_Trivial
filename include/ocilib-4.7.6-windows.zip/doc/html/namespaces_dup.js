var namespaces_dup =
[
    [ "ocilib", "namespaceocilib.html", "namespaceocilib" ]
];