var group___ocilib_c_api_abort =
[
    [ "OCI_Break", "group___ocilib_c_api_abort.html#ga64dfd04e997dc1496d09dc05b83cedf0", null ]
];