-- Initialization

create table dirpath_data (val_int int, val_str varchar2(50), val_date date);

-- Cleanup

drop table dirpath_data;

