-- Initialization DDL

create table dates (value date);


-- Cleanup DDL
 
drop table dates;
